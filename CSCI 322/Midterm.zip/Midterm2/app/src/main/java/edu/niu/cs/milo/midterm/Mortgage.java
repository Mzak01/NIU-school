//********************************************************
// CSCI322-1          MIDTERM PART1            SPRING 2024
//
// NAME: Milo Zak
//       Z-ID: Z1917365
//
// For this assignment, write an Android application that
// is a mortgage calculator
//
//********************************************************
package edu.niu.cs.milo.midterm;

import java.text.DecimalFormat;

public class Mortgage
{
    //This allows for float/double values to formatted with a leading dollar
    //sign and two digits after the decimal point
    public final DecimalFormat MONEY = new DecimalFormat("$#,##0.00");

    private float mortgage_amount;
    private int years;
    private float yearly_rate;


    //constructor
    //This creates an object with default values of $100,000 for the mortgage
    //amount, 30 years for the mortgage length, and 3.5% for the yearly interest
    //rate
    public Mortgage()
    {
        setMortgageAmount(100000.0f);
        setYears(30);
        setYearlyRate(3.5f);
    }//end Mortgage constructor


    /*
    setMortgageAmount
    This method changes the mortgage_amount data member as long as the
    newAmount argument is greater than or equal to 0
    */
    public void setMortgageAmount(float newAmount)
    {
        if (newAmount >= 0)
            mortgage_amount = newAmount;
    }


    /*
    setYears
    This method changes the years data member as long as the newYears
    argument is greater than or equal to 0
    */
    public void setYears(int newYears)
    {
        if (newYears >= 0)
            years = newYears;
    }


    /*
    setYearlyRate
    This method changes the yearly_rate data member as long as the newRate
    argument is greater than or equal to 0
    */
    public void setYearlyRate(float newRate)
    {
        if (newRate >= 0)
            yearly_rate = newRate;
    }


    /*
    The get... methods return the corresponding data member
    */
    public float getMortgageAmount()
    {
        return mortgage_amount;
    }

    public int getYears()
    {
        return years;
    }

    public float getRate()
    {
        return yearly_rate;
    }


    /*
    calculateMonthlyPayment
    This method calculates the monthly mortgage payment.
    */
    public float calculateMonthlyPayment()
    {
        //Calculate the monthly interest rate
        float monthlyRate = yearly_rate / 100 / 12;

        //calculate the a value from the Payment calculation on the application
        //description
        double aValue = Math.pow(1/(1 + monthlyRate), years * 12);

        //return the monthly payment amount
        return monthlyRate * mortgage_amount / (float) (1 - aValue);
    }//end calculateMonthlyRate method


    /*
    calculateTotalMortgage
    This method calculates the total mortgage amount over the life of the
    mortgage.
    */
    public float calculateTotalMortgage()
    {
        //monthly payment * months per year * number of years
        return calculateMonthlyPayment() * 12 * years;
    }//end calculateTotalMortgage


    /*
    formattedMortgageAmount
    This method formats the mortgage amount.
    */
    public String formattedMortgageAmount()
    {
        return MONEY.format(mortgage_amount);
    }


    /*
    formattedMonthlyPayment
    This method formats the monthly mortgage payment amount.
    */
    public String formattedMonthlyPayment()
    {
        return MONEY.format(calculateMonthlyPayment());
    }


    /*
    formattedTotalMortgage
    This method formats the total mortgage amount.
    */
    public String formattedTotalMortgage()
    {
        return MONEY.format(calculateTotalMortgage());
    }
}//end Mortgage class