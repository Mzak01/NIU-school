//********************************************************
// CSCI322-1          MIDTERM PART1            SPRING 2024
//
// NAME: Milo Zak
//       Z-ID: Z1917365
//
// For this assignment, write an Android application that
// is a mortgage calculator
//
//********************************************************
package edu.niu.cs.milo.midterm;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Toast;

public class InfoActivity extends AppCompatActivity {

    private EditText amountET, rateET;
    private RadioGroup yearsRG;
    private Mortgage mortgage;
    private String amount, rate;
    private int yearId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info);

        //connect to the screen
        amountET = findViewById(R.id.amountEditText);
        rateET = findViewById(R.id.rateEditText);
        yearsRG = findViewById(R.id.yearsRadioGroup);

        //create a new Mortgage object
        mortgage = new Mortgage();

        //connect listeners to the RadioGroup
        yearsRG.setOnCheckedChangeListener(yearsListener);

    }//end onCreate

    private RadioGroup.OnCheckedChangeListener yearsListener = new RadioGroup.OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(RadioGroup group, int checkedId) {
            if(checkedId == R.id.fifteenYearsRadioButton){
                mortgage.setYears(15);
                yearId = 15;
            }
            else if(checkedId == R.id.tenYearsRadioButton){
                mortgage.setYears(10);
                yearId = 10;
            }
            else if(checkedId == R.id.thirtyYearsRadioButton){
                mortgage.setYears(30);
                yearId = 30;
            }
        }
    };//end listener for button change in radio group


    //onClick method to go to MainActivity
    public void showData(View view){
        amount = amountET.getText().toString();
        rate = rateET.getText().toString();
        if (amount.matches("") || rate.matches("")) {
            Toast.makeText(this, "Field cannot be zero", Toast.LENGTH_LONG).show();
            return;
        }
        //for error checking edit text fields
        float amt = Float.parseFloat(amount);
        float rte = Float.parseFloat(rate);
        if(amt <= 0.0 || rte <= 0.0){
            Toast.makeText(this, "number cannot be less than 0.0", Toast.LENGTH_LONG).show();
            return;
        }
        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra("amount", amount);
        intent.putExtra("rate",rate);
        intent.putExtra("yearID", yearId);
        startActivity(intent);
    }//end showData




}//end InfoActivity