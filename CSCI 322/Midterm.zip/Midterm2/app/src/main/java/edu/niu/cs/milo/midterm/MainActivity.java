//********************************************************
// CSCI322-1          MIDTERM PART1            SPRING 2024
//
// NAME: Milo Zak
//       Z-ID: Z1917365
//
// For this assignment, write an Android application that
// is a mortgage calculator
//
//********************************************************
package edu.niu.cs.milo.midterm;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView amountTV, yearsTV, rateTV, monthlyTV, totalTV;
    String amount, rate;
    int years;
    private Mortgage mortgage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        amountTV = findViewById(R.id.amountTextView);
        yearsTV = findViewById(R.id.yearsTextView);
        rateTV = findViewById(R.id.rateTextView);
        monthlyTV = findViewById(R.id.monthlyTextView);
        totalTV = findViewById(R.id.totalTextView);

        mortgage = new Mortgage();

        //grab information which was sent
        Intent intent = getIntent();
        amount = intent.getStringExtra("amount");
        rate = intent.getStringExtra("rate");
        years = intent.getIntExtra("yearID", -999);

        //sets base amounts inputted before calculating numbers
        amountTV.setText(amount);
        rateTV.setText(rate);
        yearsTV.setText(String.valueOf(years));

        calc();
    }//end onCreate

    //method to calculate monthly and total
    public void calc(){

        //convert two strings to floats
        float mortgageAmt = Float.parseFloat(amount);
        float mortgageRate = Float.parseFloat(rate);


        //sets info in mortgage
        mortgage.setMortgageAmount(mortgageAmt);
        mortgage.setYearlyRate(mortgageRate);

        //calculates payments
        float monthlyAmt = mortgage.calculateMonthlyPayment();
        float totalAmt = mortgage.calculateTotalMortgage();

        //shows payments in textview
        monthlyTV.setText(String.valueOf(monthlyAmt));
        totalTV.setText(String.valueOf(totalAmt));


    }//end calc method

    //method to handle the button click
    public void getData(View view){
        //return to the mainActivity
        finish();
    }//end goBack

}//end MainActivity