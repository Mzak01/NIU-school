//********************************************************
// CSCI322-1          ASSIGNMENT 3             SPRING 2024
//
// NAME: Milo Zak
//       Z-ID: Z1917365
//
// For this assignment, write an Android application that
// demonstrates scrolling text
//
//********************************************************
package edu.niu.cs.milo.assign3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class HelpActivity extends AppCompatActivity {

    TextView memberTV, informationTV;
;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help);

        memberTV = findViewById(R.id.MemberTextView);
        informationTV = findViewById(R.id.JerryInfo);

        //grab information which was sent
        Intent intent = getIntent();
        String value = intent.getStringExtra("getData");
        int id = intent.getIntExtra("id", -1);
        memberTV.setText(value);

        if(id == 0){
            informationTV.setText(R.string.scroll_text_jerry);
        }
        if(id == 1){
            informationTV.setText(R.string.scroll_text_bob);
        }
        if(id == 2){
            informationTV.setText(R.string.scroll_text_phil);
        }
        if(id == 3){
            informationTV.setText(R.string.scroll_text_bill);
        }
        if(id == 4){
            informationTV.setText(R.string.scroll_text_ron);
        }


    }//end onCreate

    //method to handle the button click
    public void goBack(View view){
        //return to the mainActivity
        finish();
    }//end goBack

}//end HelpActivity