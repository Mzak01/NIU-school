//********************************************************
// CSCI322-1          ASSIGNMENT 3             SPRING 2024
//
// NAME: Milo Zak
//       Z-ID: Z1917365
//
// For this assignment, write an Android application that
// demonstrates spinners.
//
//********************************************************
package edu.niu.cs.milo.assign3;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.res.ResourcesCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private Spinner memberSpin;
    ImageView memberIV;
    private String selection;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //connect all the code to the screen
        memberIV = findViewById(R.id.memberImageView);

        //create list spinner object
        List<String> list = new ArrayList<>();
        //add band members to the list
        list.add("JERRY GARCIA");
        list.add("BOB WEIR");
        list.add("PHIL LESH");
        list.add("BILL KREUTZMANN");
        list.add("RON PIGPEN MCKERNAN");

        //connect list spinner to variables
        memberSpin = findViewById(R.id.memberSpinner);
        ArrayAdapter<String> stringArrayAdapter = new ArrayAdapter<>(getApplicationContext(), R.layout.spinner_format, list);

        memberSpin.setAdapter(stringArrayAdapter);
        memberSpin.setOnItemSelectedListener(spinnerListener);
    }//end onCreate

    //create a listener to respond to the spinner and show images based on the selection
    private AdapterView.OnItemSelectedListener spinnerListener = new AdapterView.OnItemSelectedListener() {
        @Override
        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            //string to hold selection which is grabbed from position
            selection = parent.getItemAtPosition(position).toString();

            //if statement to display images with the text
            if(selection == "JERRY GARCIA"){
                memberIV.setImageDrawable(ResourcesCompat.getDrawable(getResources(), R.drawable.jerry, null));
            }
            else if(selection == "BOB WEIR"){
                memberIV.setImageDrawable(ResourcesCompat.getDrawable(getResources(), R.drawable.bob, null));
            }
            else if(selection == "PHIL LESH"){
                memberIV.setImageDrawable(ResourcesCompat.getDrawable(getResources(), R.drawable.phil, null));;
            }
            else if(selection == "BILL KREUTZMANN"){
                memberIV.setImageDrawable(ResourcesCompat.getDrawable(getResources(), R.drawable.bill_0, null));;
            }
            else if(selection == "RON PIGPEN MCKERNAN"){
                memberIV.setImageDrawable(ResourcesCompat.getDrawable(getResources(), R.drawable.pigpen, null));;
            }
        }

        @Override
        public void onNothingSelected(AdapterView<?> parent) {

        }
    };//end AdapterView

    //method to handle the button click
    public void getHelp(View view){

        //get an id to transfer data
        int id = 0;
        if (selection == "JERRY GARCIA"){
            id = 0;
        }
        else if (selection == "BOB WEIR"){
            id = 1;
        }
        else if (selection == "PHIL LESH"){
            id = 2;
        }
        else if (selection == "BILL KREUTZMANN"){
            id = 3;
        }
        else if (selection == "RON PIGPEN MCKERNAN"){
            id = 4;
        }


        //create intent object to go to help activity
        Intent helpIntent = new Intent( MainActivity.this, HelpActivity.class);
        //send spinner information to HelpActivity
        helpIntent.putExtra("getData", selection);
        helpIntent.putExtra("id", id);
        //go to the help information
        startActivity(helpIntent);
    }//end of getHelp

}//end mainActivity