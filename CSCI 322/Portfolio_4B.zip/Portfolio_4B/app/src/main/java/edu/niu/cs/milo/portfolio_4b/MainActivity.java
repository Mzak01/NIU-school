//********************************************************
// CSCI322-1          Portfolio_4B             SPRING 2024
//
// NAME: Milo Zak
//       Z-ID: Z1917365
//
// For this assignment, write an Android application that
// demonstrates an explicit intent that returns a result.
//
//********************************************************
package edu.niu.cs.milo.portfolio_4b;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private TextView resultTV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        resultTV = findViewById(R.id.resultTextView);
    }//end oncreate

    //method for the button click
    public void getInfo(View view){
        //create the intent to go to name activity
        Intent nameIntent = new Intent(MainActivity.this, NameActivity.class);

        launcher.launch(nameIntent);

    }//end getInfo

    //create launcher to go to activity and get info
    ActivityResultLauncher<Intent> launcher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    //if the return code or the result code is ok
                    if(result.getResultCode() == RESULT_OK){
                        //get the intent that has the info
                        Intent data = result.getData();

                        //extract the name from the intent
                        String returnedName;
                        returnedName = data.getStringExtra("nameID");

                        //display the returned info
                        resultTV.setText("The returned name is " + returnedName);
                    }//end if
                }//end onActivityResult
            }
    );//end declaration launcher
}//end main