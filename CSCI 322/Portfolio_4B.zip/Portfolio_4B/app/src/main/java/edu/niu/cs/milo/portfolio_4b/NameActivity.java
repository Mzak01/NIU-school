//********************************************************
// CSCI322-1          Portfolio_4B             SPRING 2024
//
// NAME: Milo Zak
//       Z-ID: Z1917365
//
// For this assignment, write an Android application that
// demonstrates an explicit intent that returns a result.
//
//********************************************************
package edu.niu.cs.milo.portfolio_4b;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class NameActivity extends AppCompatActivity {

    private EditText nameET;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_name);

        nameET = findViewById(R.id.nameEditText);
        nameET.requestFocus();
    }//end oncreate

    //method to handle the button click
    public void returnName(View view){

        //grab info from editText field
        String nameStr = nameET.getText().toString();

        //display toast message is field is empty
        if (nameStr.matches("")){
            //display error
            Toast.makeText(this, "Field cannot be empty", Toast.LENGTH_SHORT).show();
            return;
        }

        //get intent used to call this in order to pass info back
        Intent intent = getIntent();

        //put in info to pass back to the intent
        intent.putExtra("nameID", nameStr);

        //set a result this things are ok
        setResult(RESULT_OK, intent);

        //go back to the calling activity
        finish();

    }//end returnName


}//end nameActivity