//********************************************************
// CSCI322-1          Portfolio_8             SPRING 2024
//
// NAME: Milo Zak
//       Z-ID: Z1917365
//
// For this assignment, write an Android application that
// demonstrates a logcat debugging method
//
//********************************************************
package edu.niu.cs.milo.portfolio_8;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

public class SecondActivity extends AppCompatActivity {

    static final String SA_TAG = "LIFECYCLE";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        //log for create
        String createStr = getString(R.string.create_msg);
        Log.d(SA_TAG, createStr);
    }//end onCreate

    //create log for start
    @Override
    protected void onStart() {
        super.onStart();
        String startStr = getString(R.string.start_msg);
        Log.d(SA_TAG, startStr);
    }

    //log for onResume
    @Override
    protected void onResume() {
        super.onResume();
        String resumeStr = getString(R.string.resume_msg);
        Log.d(SA_TAG, resumeStr);
    }

    //log for onPause
    @Override
    protected void onPause() {
        super.onPause();
        String pauseStr = getString(R.string.pause_msg);
        Log.d(SA_TAG, pauseStr);
    }

    //log for onStop
    @Override
    protected void onStop() {
        super.onStop();
        String stopStr = getString(R.string.stop_msg);
        Log.d(SA_TAG, stopStr);

    }

    //log for onRestart
    @Override
    protected void onRestart() {
        super.onRestart();
        String restartStr = getString(R.string.restart_msg);
        Log.d(SA_TAG, restartStr);
    }

    //log for onDestroy
    @Override
    protected void onDestroy() {
        super.onDestroy();
        String destroyStr = getString(R.string.destroy_msg);
        Log.d(SA_TAG, destroyStr);
    }

    //onClick method to go back
    public void goBack(View view){
        finish();
    }

}//end MainActivity