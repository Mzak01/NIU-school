//********************************************************
// CSCI322-1            ASSIGN1               SPRING 2024
//
// NAME: Milo Zak
//       Z-ID: Z1917365
//
// For this assignment, write an Android application that
// will have an interactive greeting/message
//
//********************************************************
package edu.niu.cs.milo.assign1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity
{
//define instance variables
private Button changeBtn;
private TextView messageTV;
private Boolean isMessage1;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //connect instance var to xml
        changeBtn = findViewById(R.id.ChangeButton);
        messageTV = findViewById(R.id.MessageTextView);

        //initialize boolean true
        isMessage1 = true;

        //onclicklistener change bttn
        //anon
        changeBtn.setOnClickListener(new View.OnClickListener() {
            //arg for onclick method that was clicked
            @Override
            public void onClick(View v) {
                //if message1 is displayed change to message2
                if( isMessage1 )
                {
                    //change to message2
                    messageTV.setText(R.string.message2);

                    //change boolean (false)
                    isMessage1 = false;

                }
                else
                {
                    messageTV.setText(R.string.message1);

                    isMessage1 = true;
                }


            }//end onclick
        });//end listener

    }//end onCreate
}//end MainActivity
