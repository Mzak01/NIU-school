//********************************************************
// CSCI322-1          ASSIGNMENT 4             SPRING 2024
//
// NAME: Milo Zak
//       Z-ID: Z1917365
//
// For this assignment, write an Android application that
// demonstrates splash screens.
//
//********************************************************

package edu.niu.cs.milo.portfolio_9;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import java.util.Timer;
import java.util.TimerTask;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        TimerTask task = new TimerTask() {
            @Override
            public void run() {
                //finish executing the splash activity
                finish();

                //start the main activity
                startActivity(new Intent(SplashActivity.this, MainActivity.class));
            }
        };//end timertask

        //create the timer object to perform the task for a set amount of time
        Timer display = new Timer();
        display.schedule(task, 3000);

    }//end oncreate
}//end splashactivity