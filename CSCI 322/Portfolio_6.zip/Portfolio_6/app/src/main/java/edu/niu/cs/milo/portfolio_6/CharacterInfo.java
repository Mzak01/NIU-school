package edu.niu.cs.milo.portfolio_6;

public class CharacterInfo {
    public static String character_name[] = { "Johnny Bravo",
            "Stewie Griffin",
            "Fred Flintstone",
            "Angelica Pickles",
            "George Jetson",
            "Velma Dinkley"};

    public static String character_quote[] = { "Hey 911 there's a handsome guy in my house! Oh wait, it's only me.",
            "Victory is mine!",
            "Yabba Dabba Dooo!",
            "You dumb babies!",
            "Yum, it's been lightyears since you programmed synthetic brownies.",
            "Jinkies"};

    public static int image_id[] = { R.drawable.character1, R.drawable.character2, R.drawable.character3,
            R.drawable.character4, R.drawable.character5, R.drawable.character6 };
}
