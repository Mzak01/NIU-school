//********************************************************
// CSCI322-1          Portfolio_5             SPRING 2024
//
// NAME: Milo Zak
//       Z-ID: Z1917365
//
// For this assignment, write an Android application that
// demonstrates implicit intents.
//
//********************************************************
package edu.niu.cs.milo.portfolio_6;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private TextView nameTV, quoteTV;
    private ImageView characterIV;
    private boolean isVisible;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //connect to screen
        nameTV = findViewById(R.id.nameTextView);
        quoteTV = findViewById(R.id.quoteTextView);
        characterIV = findViewById(R.id.characterImageView);

        //set boolean to false
        isVisible = false;
    }//end onCreate

    //method to handle the button click
    public void revealCharacter(View view){
        int charSub;
        int buttonId = view.getId();

        //decision statement to get button for char
        if(buttonId == R.id.character1button)
            charSub = 0;
        else if(buttonId == R.id.character2button)
            charSub = 1;
        else if(buttonId == R.id.character3button)
            charSub = 2;
        else if(buttonId == R.id.character4button)
            charSub = 3;
        else if(buttonId == R.id.character5button)
            charSub = 4;
        else if(buttonId == R.id.character6button)
            charSub = 5;
        else
            charSub = -999;

        //use subscript to populate textview and imageview w info
        nameTV.setText(CharacterInfo.character_name[charSub]);
        quoteTV.setText(CharacterInfo.character_quote[charSub]);

        characterIV.setImageResource(CharacterInfo.image_id[charSub]);

        //check to see if TV and IV are visible
        if(!isVisible){

            //make everything visible
            nameTV.setVisibility(View.VISIBLE);
            quoteTV.setVisibility(View.VISIBLE);
            characterIV.setVisibility(View.VISIBLE);

            //reset boolean value
            isVisible = true;
        }
    }//end revealCharacter

}//end mainActivbity