//********************************************************
// CSCI322-1           PORTFOLIO_10            SPRING 2024
//
// NAME: Milo Zak
//       Z-ID: Z1917365
//
// For this assignment, write an Android application that
// will be a dialog box
//
//********************************************************
package edu.niu.cs.milo.portfolio_10;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }//end onCreate

    //method to handle bytton click
    public void doDialog(View view){
        AlertDialog.Builder alert = new AlertDialog.Builder(this);

        //fill in the title and msg
        alert.setTitle("Dialog Box Example");
        alert.setMessage("Do you want to continue?");

        //set positive and negative response
        alert.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //display a toadt msg
                Toast.makeText(getApplicationContext(), "you clicked yes", Toast.LENGTH_LONG).show();
            }
        });

        //negative respond
        alert.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });

        //display dialog box
        alert.show();
    }//end doDialog

    @Override
    protected void onDestroy() {
        super.onDestroy();
        System.exit(0); //closes Jvm
    }
}//end MainActivity