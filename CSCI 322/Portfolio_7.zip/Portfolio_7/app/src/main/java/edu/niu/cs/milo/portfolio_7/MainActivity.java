//********************************************************
// CSCI322-1          Portfolio_7             SPRING 2024
//
// NAME: Milo Zak
//       Z-ID: Z1917365
//
// For this assignment, write an Android application that
// demonstrates a splash screen and audio
//
//********************************************************
package edu.niu.cs.milo.portfolio_7;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private MediaPlayer drumsMP, ukuleleMP;
    private Button drumsBtn, ukuleleBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //connect the buttons
        drumsBtn = findViewById(R.id.drumsButton);
        ukuleleBtn = findViewById(R.id.ukuleleButton);

        //set up the MediaPlayer
        drumsMP = new MediaPlayer();
        drumsMP.reset();
        drumsMP = MediaPlayer.create(this, R.raw.drums);

        ukuleleMP = new MediaPlayer();
        ukuleleMP.reset();
        ukuleleMP = MediaPlayer.create(this, R.raw.ukulele);
    }//end onCreate

    //method to handle button click (drums)
    public void playDrums(View view){
        //if the drums audio is playing, pause the audio
        if(drumsMP.isPlaying()){
            //pause the media player and change the text on mediaPlayer
            drumsMP.pause();

            //change the text
            drumsBtn.setText(R.string.play_drums_string);
        }
        else{
            //check if ukulele is playing. if so, make it stop
            if (ukuleleMP.isPlaying()){
                //pause ukulele
                ukuleleMP.pause();

                //change button text
                ukuleleBtn.setText(R.string.play_ukulele_string);
            }

            //start drums and update button
            drumsMP.start();

            //update drums button
            drumsBtn.setText(R.string.pause_drums_string);
        }
    }//end playDrums

    public void playUkulele(View view){
        //if the ukulele audio is playing, pause the audio
        if(ukuleleMP.isPlaying()){
            //pause the media player and change the text on mediaPlayer
            ukuleleMP.pause();

            //change the text
            ukuleleBtn.setText(R.string.play_ukulele_string);
        }
        else{
            //check if drums is playing. if so, make it stop
            if (drumsMP.isPlaying()){
                //pause ukulele
                drumsMP.pause();

                //change button text
                drumsBtn.setText(R.string.play_drums_string);
            }
            //start ukulele and update button
            ukuleleMP.start();

            //update ukulele button
            ukuleleBtn.setText(R.string.pause_ukulele_string);
        }
    }//end playUkulele

}//end mainActivity