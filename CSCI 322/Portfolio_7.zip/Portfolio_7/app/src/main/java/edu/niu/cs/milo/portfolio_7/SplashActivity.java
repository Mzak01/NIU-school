package edu.niu.cs.milo.portfolio_7;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import java.util.Timer;
import java.util.TimerTask;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        //create the task to perform
        TimerTask task = new TimerTask() {
            @Override
            public void run() {
                //finish executing the splash activity
                finish();

                //start the main activity
                startActivity(new Intent(SplashActivity.this, MainActivity.class));
            }
        };//end TimerTask

        //create the timer object to perform the task for a set amount of time
        Timer display = new Timer();
        display.schedule(task, 3000);

    }//end onCreate
}//end splashActivity