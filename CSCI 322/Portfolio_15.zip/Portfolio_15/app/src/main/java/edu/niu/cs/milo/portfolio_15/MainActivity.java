//********************************************************
// CSCI322-1           PORTFOLIO_15            SPRING 2024
//
// NAME: Milo Zak
//       Z-ID: Z1917365
//
// For this assignment, write an Android application that
// will be a weather app
//
//********************************************************
package edu.niu.cs.milo.portfolio_15;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {
    private ArrayList<Weather> weatherList;
    private WeatherAdapter weatherAdapter;
    private RecyclerView weatherRV;
    static final String LOG_TAG = "MILO";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //creaye array list
        weatherList = new ArrayList<>();

        //create the weather adapter
        weatherAdapter = new WeatherAdapter(this, weatherList);

        //coonnect the recycler view to the xml file
        weatherRV = findViewById(R.id.weatherRecyclerView);
        weatherRV.setLayoutManager(new LinearLayoutManager(this));

        //pair the adapter with the recyclerview
        weatherRV.setAdapter(weatherAdapter);
    }//end onCreate

    //dismiss keyboard when button clicked
    private void dismissKeyboard(View view){
        InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(view.getWindowToken(),0);
    }//end disiss kayboard

    //method to create a url from string
    private URL createURL(String city){
        //create string with the pword and start of web addy
        String apiKey = getString(R.string.api_key),
               baseUrl = getString(R.string.web_url);

        try {
            //try to build url the web addy, city name, imperial units, etc
            //change units to metric for celcus and standard for levin
            //cnt is num of days to display, 16 max, 7 default

            String urlString = baseUrl + URLEncoder.encode(city, "UTF-8")
                    + "&units=imperial&cnt=16&APPID=" + apiKey;

            //creae url objecy and return
            return new URL(urlString);

        }
        catch (Exception e){
            e.printStackTrace();

            return null;
        }

    }//end createURL

    //method to download JSON and put into arraylist
    private void convertJSONtoArrayList(JSONObject forecast){
        //clear info from array list
        weatherList.clear();

        try {
            //get te json array that holds the data
            //itts the JSONObject at the key
            JSONArray list = forecast.getJSONArray("List");

            //divide json array into weather objects and put into array
            for(int sub = 0; sub < list.length(); sub++){
                //retrieve the day of week
                JSONObject day = list.getJSONObject(sub);

                //get temp for the day pf week
                JSONObject temperatures = day.getJSONObject("temp");

                //get weather description and image for day of the week
                //this info is a json array that is part of the day object
                //the array has key "weather" and decription/image are at position 0
                JSONObject weather = day.getJSONArray("weather").getJSONObject(0);

                //create weater object
                Weather newWeather = new Weather(day.getLong("dt"),
                                                 temperatures.getDouble("min"),
                                                 temperatures.getDouble("max"),
                                                 day.getDouble("humidity"),
                                                 weather.getString("description"),
                                                 weather.getString("icon"));

                //add weather object to array list
                weatherList.add(newWeather);
            }//end for loop
        }
        catch (JSONException e){
            e.printStackTrace();
        }


    }//end convert method


    //method to handle bttn click
    public void getWeather(View view){
        //grab the city name from the edit text field
        EditText cityET = findViewById(R.id.cityEditText);

        URL url = createURL(cityET.getText().toString());

        //if url was created
        if (url != null) {
            //get rid of keyboard
            dismissKeyboard(cityET);

            //retrieve the weather data
            ExecutorService executor = Executors.newSingleThreadExecutor();
            Handler handler = new Handler(Looper.getMainLooper());

            executor.execute(new Runnable() {
                @Override
                public void run() {
                    //create an http object to download the info
                    HttpURLConnection connection = null;

                    //build string from json
                    StringBuilder builder = new StringBuilder();

                    try {
                        Log.d(LOG_TAG,"The url is " + url);

                        //try to open connection
                        connection = (HttpURLConnection) url.openConnection();

                        //get response code to determine if the connection was success
                        int response  = connection.getResponseCode();

                        //if connection was established
                        if (response == HttpURLConnection.HTTP_OK) {
                            //build string of info
                            try {
                                BufferedReader reader = new BufferedReader(
                                                            new InputStreamReader(connection.getInputStream()));

                                String line;
                                line = reader.readLine();

                                //while there is info to read
                                while (line != null){
                                    //append info tht was read to form string
                                    builder.append(line);

                                    //get next piece of information
                                    line = reader.readLine();
                                }//end while loop

                            }
                            catch (IOException ioException) {
                                ioException.printStackTrace();
                                Log.d(LOG_TAG, getString(R.string.read_error));
                            }

                        }
                        else {
                            //connecyion failed
                            Log.d(LOG_TAG, getString(R.string.connect_error) + "22");
                        }

                    }
                    catch (Exception e) {
                        e.printStackTrace();
                        Log.d(LOG_TAG, getString(R.string.connect_error));
                    }
                    finally {
                        //disconnect connection
                        connection.disconnect();
                    }

                    //handle info and get into recyclerview
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                JSONObject object = new JSONObject(builder.toString());

                                convertJSONtoArrayList(object);

                                //make change to adapter
                                weatherAdapter.notifyDataSetChanged();

                                //move to the top of rycleview
                                weatherRV.smoothScrollToPosition(0);
                            }
                            catch (JSONException jsonException) {
                                jsonException.printStackTrace();
                            }
                        }
                    });//end post runnable

                }
            });//end runnable

        }
        else{

        }
    }//end getWeather

}//end MainActivity