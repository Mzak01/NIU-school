//********************************************************
// CSCI322-1           PORTFOLIO_15            SPRING 2024
//
// NAME: Milo Zak
//       Z-ID: Z1917365
//
// For this assignment, write an Android application that
// will be a weather app
//
//********************************************************
package edu.niu.cs.milo.portfolio_15;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class WeatherAdapter extends RecyclerView.Adapter<WeatherAdapter.CustomViewHolder>{
    private ArrayList<Weather> WeatherData;
    private LayoutInflater inflater;
    private Context context;
    private Map<String, Bitmap> weatherBitmaps;

    //constructor


    public WeatherAdapter(Context newContext, ArrayList<Weather> newWeatherData) {
        WeatherData = newWeatherData;
        context = newContext;

        inflater = LayoutInflater.from(context);
        weatherBitmaps = new HashMap<>();
    }//end constructor

    //onCreateViewHolder

    @NonNull
    @Override
    public CustomViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
       View view = inflater.inflate(R.layout.city_view, parent, false);

        return new CustomViewHolder(view);
    }//end onCreate


    //onBindViewHolder
    @Override
    public void onBindViewHolder(@NonNull CustomViewHolder holder, int position) {
        //get weather object from arrayList at spot position
        Weather weather = WeatherData.get(position);

        //populate fields
        holder.dayTV.setText(context.getString(R.string.day_description, weather.getDayOfWeek(), weather.getDescription()));
        holder.lowTV.setText(context.getString(R.string.low_temp, weather.getMinTemp()));
        holder.highTV.setText(context.getString(R.string.high_temp, weather.getMaxTemp()));
        holder.humidityTV.setText(context.getString(R.string.humidity, weather.getHumidity()));

        //image either been placed or needs to donwload
        //if never used
        String weatherURL = weather.getIconURL();
        if(weatherBitmaps.containsKey(weatherURL)){
            //extract image from map and dispkay
            holder.conditionTv.setImageBitmap(weatherBitmaps.get(weatherURL));
        }
        else{
            //where image will download
            //be done in background
            ExecutorService service = Executors.newSingleThreadExecutor();
            Handler handler = new Handler(Looper.getMainLooper());

            service.execute(new Runnable() {
                //download image
                Bitmap bitmap = null;

                @Override
                public void run() {
                    //try to download
                    HttpURLConnection connection = null;
                    try{
                        //create url object
                        URL url = new URL(weatherURL);

                        //try to open a connection
                        connection = (HttpURLConnection) url.openConnection();

                        //try to download image
                        try {
                            //get input stream to retaive the bitmap
                            InputStream inputStream = connection.getInputStream();

                            //download the bithup
                            bitmap = BitmapFactory.decodeStream(inputStream);

                            //download input stream
                            weatherBitmaps.put(weatherURL, bitmap );
                        }//end inner try
                        catch (Exception e){
                            //cant download image
                            e.printStackTrace();
                        }//end inner catch


                    }//end try
                    catch (Exception exception){
                        //invalid url
                        exception.printStackTrace();
                    }//end catch
                    finally {
                        //disconnet the connection
                        connection.disconnect();
                    }//end finally

                    //display image downloaded
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            //display bitmap
                            holder.conditionTv.setImageBitmap(bitmap);
                        }
                    });//end runnale

                }//end run method
            });//end executor execute
        }//end if else
    }//end onBind

    //getItemCount
    @Override
    public int getItemCount() {
        return WeatherData.size();
    }

    //custom viewholder
    public class CustomViewHolder extends RecyclerView.ViewHolder{
        public ImageView conditionTv;
        public TextView dayTV, lowTV, highTV, humidityTV;

        //constructor
        public CustomViewHolder(@NonNull View itemView)
        {
            super(itemView);

            //connect members to the xml file
            dayTV = itemView.findViewById(R.id.dayTextView);
            highTV = itemView.findViewById(R.id.highTextView);
            lowTV = itemView.findViewById(R.id.lowTextView);
            humidityTV = itemView.findViewById(R.id.humidityTextView);

            conditionTv = itemView.findViewById(R.id.conditionImageView);
        }//end constructor
    }//end custom view holder

}//end weatheradpater
