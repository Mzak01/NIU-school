//********************************************************
// CSCI322-1          Assignment_2             SPRING 2024
//
// NAME: Milo Zak
//       Z-ID: Z1917365
//
// For this assignment, write an Android application that
// will calculate a quadratic equation
//
//********************************************************
package edu.niu.cs.milo.assign2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    private EditText AET, BET, CET;
    private TextView result1TV, result2TV;
    private Button clearBtn, calculateBtn;
    private double numA, numB, numC, result1, result2, discriminant;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //connect instance variables to items on the screen
        AET = findViewById(R.id.aEditText);
        BET = findViewById(R.id.bEditText);
        CET = findViewById(R.id.cEditText);

        result1TV = findViewById(R.id.result1TextView);
        result2TV = findViewById(R.id.result2TextView);

        calculateBtn = findViewById(R.id.calculateButton);
        clearBtn = findViewById(R.id.clearButton);

        //decimal formatting
        final DecimalFormat df = new DecimalFormat("#.00");

        calculateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //check for an empty field or a field with 0. Display error message and do nothing
                if(AET.getText().toString().matches("")) {
                    Toast.makeText(v.getContext(), "The numeric fields cannot be empty", Toast.LENGTH_LONG).show();
                    return;
                }
                if(BET.getText().toString().matches("")) {
                    Toast.makeText(v.getContext(), "The numeric fields cannot be empty", Toast.LENGTH_LONG).show();
                    return;
                }
                if (CET.getText().toString().matches("")) {
                    Toast.makeText(v.getContext(), "The numeric fields cannot be empty", Toast.LENGTH_LONG).show();
                    return;
                }
                if(AET.getText().toString().matches("0")) {
                    Toast.makeText(v.getContext(), "The numeric field A cannot be zero", Toast.LENGTH_LONG).show();
                    return;

                }

                //parse input to manipulate
                numA = Double.parseDouble(AET.getText().toString());
                numB = Double.parseDouble(BET.getText().toString());
                numC = Double.parseDouble(CET.getText().toString());

                //calc discriminant
                discriminant = Math.pow(numB,2) - 4 * numA * numC;

                //if discrim is positive (2 output)
                //test 1,3,1
                if(discriminant > 0) {
                    result1 = (-numB + Math.sqrt(discriminant))/(2*numA);
                    result2 = (-numB - Math.sqrt(discriminant))/(2*numA);

                    //display result
                    result1TV.setText(df.format(result1));
                    result2TV.setText(df.format(result2));
                }
                //if discrim is zero (1 output)
                //test 1,2,1
                else if (discriminant == 0) {
                    result1 = (-numB + Math.sqrt(discriminant))/(2*numA);

                    result1TV.setText(df.format(result1));
                    result2TV.setText(df.format(result1));
                }
                //discrim is neg (0 output)
                //test 1,-3,5
                else {
                    result1TV.setText("Imaginary");
                    result2TV.setText("Imaginary");
                }

            }
        });//end onClick Listener calculate

        //set up anon listener for the clear button
        clearBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //clears input fields
                AET.setText("");
                BET.setText("");
                CET.setText("");

                //clears answer fields
                result1TV.setText("");
                result2TV.setText("");

                //make cursor go back to first num on field
                AET.requestFocus();
            }
        });//end of clear onClick listener

    }//end onCreate
}//end mainActivity