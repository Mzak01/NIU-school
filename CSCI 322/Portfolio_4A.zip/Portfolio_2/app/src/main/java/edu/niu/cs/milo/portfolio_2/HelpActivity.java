//********************************************************
// CSCI322-1          Portfolio_4             SPRING 2024
//
// NAME: Milo Zak
//       Z-ID: Z1917365
//
// For this assignment, write an Android application that
// will display a help page
//
//********************************************************
package edu.niu.cs.milo.portfolio_2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;

public class HelpActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help);
    }//end of onCreate

    //method to handle the button click
    public void goBack(View view){
        //return to the mainActivity
        finish();
    }//end goback

}//end of main