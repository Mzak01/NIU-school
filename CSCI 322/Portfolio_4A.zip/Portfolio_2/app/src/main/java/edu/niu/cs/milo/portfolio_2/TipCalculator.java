package edu.niu.cs.milo.portfolio_2;

public class TipCalculator
{
    private float tip, bill;

    public TipCalculator(float newTip, float newBill)
    {
        tip = newTip;
        bill = newBill;
    }

    public float getTip()
    {
        return tip;
    }

    public float getBill()
    {
        return bill;
    }

    public void setTip(float newTip)
    {
        tip = 0.0f;
        if( newTip > 0.0f)
        {
            tip = newTip;
        }
    }

    public void setBill(float newBill)
    {
        bill = 0.0f;
        if(newBill > 0.0f)
        {
            bill = newBill;
        }
    }

    //method to calc the tip amount
    public float calculateTip()
    {
        return bill * tip;
    }

    //method to calc total
    public float calculateTotal()
    {
        return bill + calculateTip();
    }
}//end TipCalculator
