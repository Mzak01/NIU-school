//********************************************************
// CSCI322-1          Portfolio_2             SPRING 2024
//
// NAME: Milo Zak
//       Z-ID: Z1917365
//
// For this assignment, write an Android application that
// will calculate the tip and the bill.
//
//********************************************************
package edu.niu.cs.milo.portfolio_2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.NumberFormat;

public class MainActivity extends AppCompatActivity {

    private TipCalculator tipCalculator;
    public NumberFormat money;
    private EditText billET, tipPercET;
    private TextView tipTV, totalTV;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //connect to the items on screen
        billET = findViewById(R.id.billEditText);
        tipPercET = findViewById(R.id.tipPercentEditText);

        tipTV = findViewById(R.id.tipTextView);
        totalTV = findViewById(R.id.totalTextView);

        //create tip calc object
        tipCalculator = new TipCalculator( 0.17f, 100.0f);

        //create num format object for dollar amount
        money = NumberFormat.getCurrencyInstance();

        //add a custom text watcher to the edit text fields
        TextChangeHandler textChangeHandler = new TextChangeHandler();

        billET.addTextChangedListener(textChangeHandler);
        tipPercET.addTextChangedListener(textChangeHandler);

        //put focus on the bill edit text
        billET.requestFocus();

    }//end oncreate

    //method to calc tip amount and total
    public void calculate()
    {
        //get val from edit text fields
        String billString = billET.getText().toString();
        String tipPercString = tipPercET.getText().toString();

        //check for an empty field (stop if empty)
        if(billString.matches("") || tipPercString.matches(""))
        {
            return;
        }
        //convert strings to numeric values and calculate
        try
        {
            float billAmt = Float.parseFloat(billString);
            int tipPerc = Integer.parseInt(tipPercString);

            //update the tip calculatir object
            tipCalculator.setTip(tipPerc * 0.01f);
            tipCalculator.setBill(billAmt);

            //calculate the tip amount and total bill amount
            float tip = tipCalculator.calculateTip();
            float total = tipCalculator.calculateTotal();

            //display totals in boxes
            tipTV.setText(money.format(tip));
            totalTV.setText(money.format(total));
        }
        catch (NumberFormatException nfe)
        {
            //display toast message
            Toast.makeText(this, "Data is invalid", Toast.LENGTH_SHORT).show();
        }
    }//end calculate method

    //custom text watcher
    private class TextChangeHandler implements TextWatcher
    {
        @Override
        public void afterTextChanged(Editable s) {
            calculate();
        }

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {

        }
    }//end TextChangeHandler class



}//end main