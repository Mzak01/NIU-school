//********************************************************
// CSCI322-1          Portfolio_3             SPRING 2024
//
// NAME: Milo Zak
//       Z-ID: Z1917365
//
// For this assignment, write an Android application that
// will build a burger from a resturant and show calories
//
//********************************************************
package edu.niu.cs.milo.portfolio_3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private RadioGroup pattyRG, cheeseRG;
    private TextView caloriesTV;
    private CheckBox baconCB;

    //burger class
    private Burger burger;
    private SeekBar sauceSB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //connect to screen
        pattyRG = findViewById(R.id.pattyRadioGroup);
        caloriesTV = findViewById(R.id.caloriesTextView);
        baconCB = findViewById(R.id.baconCheckBox);
        cheeseRG = findViewById(R.id.cheeseRadioGroup);
        sauceSB = findViewById(R.id.sauceSeekBar);

        //create burger object
        burger = new Burger();

        //display initial number of calories
        displayCalories();

        //connect the Listeners to the objects
        pattyRG.setOnCheckedChangeListener(pattyListener);
        baconCB.setOnClickListener(baconListener);

        //set up on checked change listener (anon) for cheese
        cheeseRG.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if(checkedId == R.id.noCheeseRadioButton)
                {
                    burger.setCheeseCalories(0);
                }
                else if (checkedId == R.id.mozzRadioButton) {
                    burger.setCheeseCalories(Burger.MOZZARELLA);
                }
                else
                    burger.setCheeseCalories(Burger.CHEDDAR);

                //display updated calories
                displayCalories();
            }
        });

        //set up listener for sauce seek bar (anon)
        sauceSB.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                //use the progress argument to determine amount of sauce on a burger
                burger.setSauceCalories(progress);

                //display updated calories
                displayCalories();
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }//end oncreate

    //Listener for checkbox
    private View.OnClickListener baconListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if(baconCB.isChecked())
                burger.setBaconCalories(true);
            else
                burger.setBaconCalories(false);

            displayCalories();
        }
    };

    //listener for the patty radio group
    private RadioGroup.OnCheckedChangeListener pattyListener = new RadioGroup.OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(RadioGroup group, int checkedId) {
            if(checkedId == R.id.beefRadioButton)
            {
                burger.setPattyCalories(Burger.BEEF);
            }
            else if (checkedId == R.id.turkeyRadioButton)
            {
                burger.setPattyCalories(Burger.TURKEY);
            }
            else
                burger.setPattyCalories(Burger.VEGGIE);

            displayCalories();
        }
    };


    //method to display the num of calories
    private void displayCalories()
    {
        String caloriesString = "Calories: " + burger.getTotalCalories();

        //put a string in the textveiw
        caloriesTV.setText(caloriesString);
    }
}//end main