package edu.niu.cs.milo.portfolio_3;

public class Burger
{
    //constants
    static final int BEEF = 90,
                     TURKEY = 170,
                     VEGGIE = 150;

    static final int CHEDDAR = 113,
                     MOZZARELLA = 78,
                     NO_CHEESE = 0,
                     BACON = 86;

    private int pattyCalories, baconCalories, cheeseCalories, sauceCalories;

    //constructor
    public Burger()
    {
        pattyCalories = BEEF;
        baconCalories = 0;
        cheeseCalories = 0;
        sauceCalories = 0;
    }//end constructor

    //setters
    public void setPattyCalories(int pattyCalories) {
        this.pattyCalories = pattyCalories;
    }

    public void setBaconCalories(boolean hasBacon) {
        if( hasBacon )
            this.baconCalories = BACON;
        else
            baconCalories = 0;
    }

    public void setCheeseCalories(int cheeseCalories) {
        this.cheeseCalories = cheeseCalories;
    }

    public void setSauceCalories(int sauceCalories) {
        this.sauceCalories = sauceCalories;
    }

    //method to calculate total calories
    public int getTotalCalories()
    {
        return pattyCalories + cheeseCalories + baconCalories + sauceCalories;
    }



}//end Burger Class
