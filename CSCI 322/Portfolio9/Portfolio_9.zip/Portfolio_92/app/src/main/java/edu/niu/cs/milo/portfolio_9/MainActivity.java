//********************************************************
// CSCI322-1           PORTFOLIO_9             SPRING 2024
//
// NAME: Milo Zak
//       Z-ID: Z1917365
//
// For this assignment, write an Android application that
// will be a pizzle game
//
//********************************************************
package edu.niu.cs.milo.portfolio_9;

import androidx.appcompat.app.AppCompatActivity;

import android.content.res.Resources;
import android.graphics.Point;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnTouchListener
{

//    private TextView textView;
//    private RelativeLayout.LayoutParams params;
//    private int startX, startY, startTouchX, startTouchY;

    //constant that resembles the size as the status bar
    private final static int STATUS_BAR_HEIGHT = 24;
    private final static int ACTION_BAR_HEIGHT = 56; //optonal

    private Puzzle puzzle;
    private PuzzleView puzzleView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        buildGUIByCode();
    }//end onCreate

    public void buildGUIByCode(){

        //create the puzzle object
        puzzle = new Puzzle();

        //determine screen size
        Point size = new Point();
        getWindowManager().getDefaultDisplay().getSize(size);

        //get width and height of the screem
        int screenWidth = size.x, screenHeight = size.y;

        //find the size of the pixel
        Resources resources = getResources();
        DisplayMetrics metrics = resources.getDisplayMetrics();
        float pixelDensity = metrics.density;

        //determine the height of the status bar
        int statusBarHeight = (int) (pixelDensity * STATUS_BAR_HEIGHT);
        int resourceID = resources.getIdentifier("status_bar_height", "dimen", "android");

        //if the status bar height is diff than typical default resizr
        if(resourceID != 0 ){
            statusBarHeight = resources.getDimensionPixelSize(resourceID);
        }

        //optional for displays with action bat
        int actionBarHeight = (int) (pixelDensity * ACTION_BAR_HEIGHT);
        TypedValue typedValue = new TypedValue();
        if (getTheme().resolveAttribute(android.R.attr.actionBarSize, typedValue, true)) {
            //reset the height of action bar
            actionBarHeight = TypedValue.complexToDimensionPixelSize(typedValue.data, metrics);
        }

        //calculate height for the puzzle
        int puzzleHeight = screenHeight - statusBarHeight - actionBarHeight;

        //create the puzzleview object
        puzzleView = new PuzzleView(this, screenWidth, puzzleHeight, puzzle.getNumPieces());


        //create the text for the puzzle using scramble
        String[] scrambledPuzzle = puzzle.scramble();

        //fill in the puzzleview with scrambled puzzle
        puzzleView.fillGUI(scrambledPuzzle);

        //put a touch listener to the puzzleview
        puzzleView.enableListener(this);

        //display the puzzle
        setContentView(puzzleView);

/*        //create the textview and set a background color
        textView = new TextView(this);
        textView.setBackgroundColor(0xFFFF0000);

        //create the relative layout and the params for where the textview starts
        RelativeLayout layout = new RelativeLayout(this);

        params = new RelativeLayout.LayoutParams(300, 200);
        params.leftMargin = 50;
        params.topMargin = 150;

        //add the textview to the layout using the params
        layout.addView(textView, params);

        //make the layout visible
        setContentView(layout);

        //attach the touch listener to the touch view
        textView.setOnTouchListener(this);
*/    }//end buildGUIByCode method

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        int action = event.getAction();
        int index = puzzleView.indexOfTextView(v);

        switch(action)
        {
            case MotionEvent.ACTION_DOWN:
                Log.w("MILO", "Down view = " + v + " event " + event);

                puzzleView.updateStartPosition(index, (int)event.getY());
                //make sure text view is being moved is always on top and never goes behind
                puzzleView.bringChildToFront(v);


/*                //get where the touch occurred
                startX = params.leftMargin;
                startY = params.topMargin;

                startTouchX = (int) event.getX();
                startTouchY = (int) event.getY();
*/                break;
            case MotionEvent.ACTION_MOVE:
                Log.w("MILO", "Move view = " + v + " event " + event);

                puzzleView.moveTextViewVertically(index, (int)event.getY());

/*                //update the params and redraw textview
                params.leftMargin = startX + (int) event.getX() - startTouchX;
                params.topMargin = startY + (int) event.getY() - startTouchY;

                //reset the params on the textview
                textView.setLayoutParams(params);
*/                break;
            case MotionEvent.ACTION_UP:
                Log.w("MILO", "UP view = " + v + " event " + event);

                //if user has lifted finger off screen moved to where want
                //swap pieces here
                int newPosition = puzzleView.tvPosition(index);
                puzzleView.placeTextViewAtPosition(index, newPosition);

                //determine if solved, if has disable
                if (puzzle.solved(puzzleView.currentSolution())) {
                    puzzleView.disableListener();
                }

                break;
        }

        return true;
    }
}//end MainActivity