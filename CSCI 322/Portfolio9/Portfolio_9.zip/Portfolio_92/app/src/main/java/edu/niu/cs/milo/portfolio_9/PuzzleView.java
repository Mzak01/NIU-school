//********************************************************
// CSCI322-1           PORTFOLIO_9             SPRING 2024
//
// NAME: Milo Zak
//       Z-ID: Z1917365
//
// For this assignment, write an Android application that
// will be a pizzle game
//
//********************************************************
package edu.niu.cs.milo.portfolio_9;

import android.content.Context;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class PuzzleView extends RelativeLayout {

    //array of textview that make the puzzle
    private TextView [] textViewPieces;

    //array of params for the textviews
    private RelativeLayout.LayoutParams [] params;

    //array of colors for each textview
    private int [] pieceColors;

    //height for the textview
    private int textViewHeight;

    private int startY, startTouchY;

    //variable to hold y of where piece was located
    private int emptyPosition;

    //array to hold y of all text views
    private int[] positions;

    //constructor

    public PuzzleView(AppCompatActivity activity, int width, int height, int numPieces) {
        super(activity);

        buildViewGUI(activity, width, height, numPieces);
    }//end constructor

    public void buildViewGUI(AppCompatActivity activity, int width, int height, int numPieces){
        //create the array of positions
        positions = new int[numPieces];

        //create the three arrays
        textViewPieces = new TextView[numPieces];
        params = new LayoutParams[numPieces];
        pieceColors = new int[numPieces];

        //create a random num gen to create colors
        Random random = new Random();

        //calculate the height for the textviees
        textViewHeight = height / numPieces;

        //loop to create the individual textview and put the in array
        //also do the colors and location for textviews
        for(int sub = 0; sub < textViewPieces.length; sub++){
            //create an indiviual textview and put into array
            textViewPieces[sub] = new TextView(activity);

            //make the text center in the textView
            textViewPieces[sub].setGravity(Gravity.CENTER);

            //random color for the textview
            pieceColors[sub] = Color.rgb(random.nextInt(255),
                                         random.nextInt(255),
                                         random.nextInt(255));

            //set the background of the textview
            textViewPieces[sub].setBackgroundColor(pieceColors[sub]);

            //set the params
            params[sub] = new LayoutParams(width, textViewHeight);

            //set up the x and y coord
            params[sub].leftMargin = 0;
            params[sub].topMargin = textViewHeight * sub;

            //add the view to the screen
            addView(textViewPieces[sub], params[sub]);
        }
    }//end build method

    //methodto populate the textviews
    public void fillGUI(String [] puzzleText){
        //loop to fill the array of textviews
        for (int sub = 0; sub < textViewPieces.length; sub++){
            textViewPieces[sub].setText(puzzleText[sub]);

            //save the y for current textview
            positions[sub] = sub;
        }
    }//end fillGUI

    //method to find subscript of textview being moved
    public int indexOfTextView(View view){
        //verify the passed view object is textview
        //if not return invalid subscript
        if( !(view instanceof TextView)){
            return -1;
        }

        //find the subscript of the text view thats moved
        for (int sub = 0; sub < textViewPieces.length;sub++){
            if(view == textViewPieces[sub])
                return sub;
        }

        //return invalid subscript to indicate no match found
        return -1;
    }//end of index method

    //method to update the y when touch happens
    public void updateStartPosition(int index, int y){
        startY = params[index].topMargin;
        startTouchY = y;

        //update he position of the tv that was touched
        emptyPosition = tvPosition(index);
    }//end update start pos

    //method to update textview and do the moving
    public void moveTextViewVertically(int index, int y){
        params[index].topMargin = startY + y - startTouchY;
        textViewPieces[index].setLayoutParams(params[index]);
    }//end move method

    //method to add touch listener to each textview
    public void enableListener(OnTouchListener listener){
        for (int sub = 0; sub < textViewPieces.length; sub++){
            textViewPieces[sub].setOnTouchListener(listener);
        }
    }//end enable listener

    //methpd to disab;e touching of textvoew
    public void disableListener(){
        for (int sub = 0; sub < textViewPieces.length; sub++){
            textViewPieces[sub].setOnTouchListener(null);
        }
    }//end disableListener

    //method to return the subscript of the textview we are moving
    public int tvPosition(int tvIndex){
        return (params[tvIndex].topMargin + textViewHeight/2) / textViewHeight;
    }//end position method

    //method to swap textviews
    public void placeTextViewAtPosition(int tvIndex, int toPosition){
        //move the tv to position toPosition
        params[tvIndex].topMargin = toPosition * textViewHeight;

        textViewPieces[tvIndex].setLayoutParams(params[tvIndex]);

        //move replaced textview to open spot
        int index = positions[toPosition];
        params[index].topMargin = emptyPosition * textViewHeight;

        textViewPieces[index].setLayoutParams(params[index]);

        //reset values in positions array
        positions[emptyPosition] = index;
        positions[toPosition] = tvIndex;
    }//end place tv method

    //method return what is currently on screen of puzzle
    //determines if solved
    public  String [] currentSolution(){
        String [] current = new String[textViewPieces.length];

        for (int sub = 0; sub < textViewPieces.length; sub++){
            current[sub] = textViewPieces[positions[sub]].getText().toString();
        }
        return current;
    }//end solution


}//end PuzzleView
