//********************************************************
// CSCI428-1              Assign5                SPRING 25
//
// NAME: Milo Zak
//       Z-ID: Z1917365
//
// write an Android application that helps the app's user
// retrieve the parking location of his or her car.
//********************************************************
package edu.niu.cs.milo.locator;

import edu.niu.cs.milo.locator.databinding.ActivityMapsBinding;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import android.location.Location;
import android.os.Bundle;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;

import androidx.core.app.ActivityCompat;
import android.Manifest;
import android.widget.Toast;
import android.view.View;
import android.widget.Button;
import android.content.pm.PackageManager;

import com.google.android.gms.maps.model.CircleOptions;
import android.content.SharedPreferences;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private FusedLocationProviderClient fusedLocationClient;
    private static final int LOCATION_REQUEST_CODE = 101;
    private ActivityMapsBinding binding;

    //Variables for storing and retrieving the car's location
    private static final String CAR_LOCATION_PREFERENCE = "carLocationPreference";
    private static final String CAR_LONGITUDE = "locationLongitude";
    private static final String CAR_LATITUDE = "locationLatitude";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        binding = ActivityMapsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Initialize SupportMapFragment programmatically
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map_container);

        if (mapFragment == null) {
            mapFragment = SupportMapFragment.newInstance();
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.map_container, mapFragment)
                    .commit();
        }

        mapFragment.getMapAsync(this);

        // Button to store the car's location
        Button saveLocationButton = findViewById(R.id.save_location_button);
        saveLocationButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                storeCarLocation();
            }
        });

        // Button to show the saved car's location
        Button showCarLocationButton = findViewById(R.id.show_car_location_button);
        showCarLocationButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showCarLocation();
            }
        });
    }//end OnCreate

    private void storeCarLocation() {
        //Permissions
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            //Get permissions if there is none
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, LOCATION_REQUEST_CODE);
            return;
        } //end permission section

        //We have permissions so we can code
        fusedLocationClient.getLastLocation()
                .addOnSuccessListener(this, new OnSuccessListener<Location>() {
                    @Override
                    public void onSuccess(Location location) {   // Get the location
                        if (location != null) { //If we have a location save it so we can access it later
                            double locationLatitude = location.getLatitude();
                            double locationLongitude = location.getLongitude();

                            //Saving
                            SharedPreferences sharedPreferences = getSharedPreferences(CAR_LOCATION_PREFERENCE, MODE_PRIVATE);
                            SharedPreferences.Editor editor = sharedPreferences.edit();
                            editor.putLong(CAR_LATITUDE, Double.doubleToRawLongBits(locationLatitude));
                            editor.putLong(CAR_LONGITUDE, Double.doubleToRawLongBits(locationLongitude));
                            editor.apply();
                            Toast.makeText(MapsActivity.this, "Saved location", Toast.LENGTH_SHORT).show();

                        }
                    }
                }) // End onSuccessListerner
                .addOnFailureListener(this, new OnFailureListener() { //If car not saved error out
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(MapsActivity.this, "Failed: save location", Toast.LENGTH_SHORT).show();
                    } //End onFailure
                });
    }// ENd storeLocation

    private void showCarLocation() {
        double longitude;
        double latitude;
        //Get cars location
        SharedPreferences sharedPreferences = getSharedPreferences(CAR_LOCATION_PREFERENCE, MODE_PRIVATE);
        double locationLatitude = Double.longBitsToDouble(sharedPreferences.getLong(CAR_LATITUDE, Double.doubleToRawLongBits(0)));
        double locationLongitude = Double.longBitsToDouble(sharedPreferences.getLong(CAR_LONGITUDE, Double.doubleToRawLongBits(0)));

        //If no location make a new location
        if (locationLatitude != 0 && locationLongitude != 0) {
            LatLng carLocation = new LatLng(locationLatitude, locationLongitude);

            //Add a marker for car location
            mMap.addCircle(new CircleOptions()
                    .center(carLocation)
                    .radius(20) //Circle Radius
                    .strokeColor(0xFFFF0000) //RED
                    .fillColor(0x30FF0000)); //More RED
            //Add marking making it "CAR"
            mMap.addMarker(new MarkerOptions().position(carLocation).title("CAR"));

            //Go to location
            CameraUpdate update = CameraUpdateFactory.newLatLngZoom(carLocation, 15f);
            mMap.moveCamera(update);
        } else { //if there is no data make starting data
            Toast.makeText(this, "No Data", Toast.LENGTH_SHORT).show();
            longitude = -34;
            latitude = 151;
            LatLng locationLatLng = new LatLng(latitude, longitude);
            CameraUpdate update = CameraUpdateFactory.newLatLngZoom(locationLatLng, 1.5f);
            mMap.moveCamera(update);
        }
    } //End showCarLocation

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // Check for location permission and enable the My Location layer
        if (ActivityCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)
        {
            mMap.setMyLocationEnabled(true);

            // Retrieve last known location
            fusedLocationClient.getLastLocation()
                    .addOnSuccessListener(this, new OnSuccessListener<Location>() {
                        @Override
                        public void onSuccess(Location location) {
                            double longitude;
                            double latitude;
                            if (location != null) {
                                LatLng locationLatLng = new LatLng(location.getLatitude(), location.getLongitude());
                                CameraUpdate update = CameraUpdateFactory.newLatLngZoom(locationLatLng, 15f); // Zoomed in for closer view
                                mMap.moveCamera(update);
                            } else {
                                Toast.makeText(MapsActivity.this, "Failed to get the current location. Using fallback location.", Toast.LENGTH_SHORT).show();
                                longitude = -34;
                                latitude = 151;
                                LatLng locationLatLng = new LatLng(latitude, longitude);
                                CameraUpdate update = CameraUpdateFactory.newLatLngZoom(locationLatLng, 1.5f);
                                mMap.moveCamera(update);
                            }
                        }
                    }) //End onSuccess
                    .addOnFailureListener(this, new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(MapsActivity.this, "Failed to get the current location. Using fallback location.", Toast.LENGTH_SHORT).show();
                        }
                    }); //end onFailure
            //broke things womp womp commented out
//            double longitude = -34;
//            double latitude = 151;

//            LatLng locationLatLng = new LatLng(latitude, longitude);
//            CameraUpdate update = CameraUpdateFactory.newLatLngZoom(locationLatLng, 1.5f);
//            mMap.moveCamera(update);
        }
        else
        {
            // Request permission if not granted
            requestPermission(
                    Manifest.permission.ACCESS_FINE_LOCATION, LOCATION_REQUEST_CODE);
        }
    } //end onMapReady

    // From file
    protected void requestPermission(String permissionType, int requestCode)
    {
        ActivityCompat.requestPermissions(this,
                new String[]{permissionType}, requestCode
        );
    } //end RequestPermission

    //from file
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode)
        {
            case LOCATION_REQUEST_CODE:
            {

                if (grantResults.length == 0
                        || grantResults[0] != PackageManager.PERMISSION_GRANTED)
                {
                    Toast.makeText(this,
                            "Unable to show location - permission required", Toast.LENGTH_LONG).show();
                }
                else
                {
                    SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                            .findFragmentById(R.id.map_container);
                    mapFragment.getMapAsync(this);
                }
            }
        }
    } //end onRequestPermissionResult
} //End prog
