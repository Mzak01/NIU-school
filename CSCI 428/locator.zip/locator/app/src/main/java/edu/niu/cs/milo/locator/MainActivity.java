//********************************************************
// CSCI428-1              Assign5                SPRING 25
//
// NAME: Milo Zak
//       Z-ID: Z1917365
//
// write an Android application that
// add bubble text to picture
//
//********************************************************
package edu.niu.cs.milo.locator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}