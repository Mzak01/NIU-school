//********************************************************
// CSCI428-1              Assign3                SPRING 25
//
// NAME: Milo Zak
//       Z-ID: Z1917365
//
// write a speech regonition math program
//
//********************************************************
package edu.niu.cs.milo.addtwo;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.speech.RecognizerIntent;
import android.widget.Button;
import android.widget.TextView;
import java.util.Random;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {
    private TextView mathTextView;
    private TextView resultTextView;
    private Button startButton;
    private Button searchVoiceButton;

    private int getNum1,
                getGetNum2,
                isAnswerRight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //set everything up
        mathTextView = findViewById(R.id.mathtextView);
        resultTextView = findViewById(R.id.resultTextView);
        startButton = findViewById(R.id.startButton);
        searchVoiceButton = findViewById(R.id.searchVoiceButton);

        //starts the math
        startButton.setOnClickListener(view -> startMath());

        //recognize voice
        searchVoiceButton.setOnClickListener(view -> startVoice());

        //new math to procude (I canot spell recognition)
        startMath();
    }//end onCreate

    private void startMath() {
        Random random = new Random();
        getNum1 = random.nextInt(10);  //I miss when math was this easy
        getGetNum2 = random.nextInt(10);
        isAnswerRight = getNum1 + getGetNum2;

        mathTextView.setText(getNum1 + "+" + getGetNum2);
        resultTextView.setText("");
    }//end startMath

    //I am using knowSpeech because I cannot keep questioning how to spell
    private void startVoice() {
        Intent listenIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        listenIntent.putExtra(RecognizerIntent.EXTRA_PROMPT,
                "What's the secret answer?");
        listenIntent.putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);

        startActivityForResult(listenIntent, 100); //uses onActivityResult
    }//end startVoice

    //dies the math in the backgrround to show answer as right or wrong
    protected void onActivityResult(
            int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 100 && resultCode ==
                RESULT_OK) {
            String recognizedText = data.getStringArrayListExtra(
                    RecognizerIntent.EXTRA_RESULTS).get(0);
            int runnableAsnwer = Integer.parseInt(recognizedText); //makes int

            if(runnableAsnwer == isAnswerRight) {
                resultTextView.setText("CORRECT!");
            } else {
                resultTextView.setText("WRONG!");
            } //end right/wrong ifs
        }//end if
    }//end onActivityResult
}//end MainActivity