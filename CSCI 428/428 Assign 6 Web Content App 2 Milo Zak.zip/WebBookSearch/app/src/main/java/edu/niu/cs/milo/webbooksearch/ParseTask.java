//********************************************************
// CSCI428-1              Assign6                SPRING 25
//
// NAME: Milo Zak
//       Z-ID: Z1917365
//
// Write an app similar to the Web Content App we built in Chapter 6: XML and Content Apps.
// Default to as many titles as have been published but add a text field to let users specifiy
//how recent they want the data to be.
//********************************************************
package edu.niu.cs.milo.webbooksearch;

import android.os.AsyncTask;
import android.util.Log;
import java.util.ArrayList;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

public class ParseTask extends AsyncTask<String, Void, ArrayList<Item>>
{
    private MainActivity activity;
    private String searchByKeyword;

    public ParseTask(MainActivity fromActivity, String term)
    {
        activity = fromActivity;
        if (term != null) {
            searchByKeyword = term.toLowerCase();
        } else {
            searchByKeyword = "";
        }
    }

    protected ArrayList<Item> doInBackground(String... urls)
    {
        try
        {
            SAXParserFactory factory = SAXParserFactory.newInstance();
            SAXParser saxParser = factory.newSAXParser();
            SAXHandler handler = new SAXHandler();
            saxParser.parse(urls[0], handler);
            return handler.getItems();
        }
        catch (Exception e)
        {
            Log.w("MainActivity", e.toString());
            return null;
        }
    }

    protected void onPostExecute(ArrayList<Item> returnedItems)
    {
        if (returnedItems == null || searchByKeyword.isEmpty()) {
            activity.displayList(returnedItems);  // no filtering -> display
            return;
        }

        ArrayList<Item> filtered = new ArrayList<>();
        for (Item item : returnedItems) {
            if (item.getTitle().toLowerCase().contains(searchByKeyword))
                filtered.add(item);
        }
        activity.displayList(filtered);
    }
}
