//********************************************************
// CSCI428-1              Assign6                SPRING 25
//
// NAME: Milo Zak
//       Z-ID: Z1917365
//
// Write an app similar to the Web Content App we built in Chapter 6: XML and Content Apps.
// Default to as many titles as have been published but add a text field to let users specifiy
//how recent they want the data to be.
//********************************************************
package edu.niu.cs.milo.webbooksearch;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity
{
    private final String URL = "https://www.nintendoworldreport.com/rss";

    private ListView listView;
    private ArrayList<Item> listItems;
    private EditText searchBox;           // For searching
    private Button searchButton;             // For searching

    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = (ListView) findViewById(R.id.list_view);
        searchBox = findViewById(R.id.search_box);     // to search by keyword
        searchButton = findViewById(R.id.search_button);     // to enter search by keyword

        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String term = searchBox.getText().toString().trim();  //get the search and parse
                ParseTask task = new ParseTask(MainActivity.this, term);
                task.execute(URL);
            }
        });
        ParseTask task = new ParseTask(this, "");
        task.execute(URL);
    }

    public void displayList(ArrayList<Item> items)
    {
        listItems = items;
        if (items != null)
        {
            ArrayList<String> titles = new ArrayList<String>();
            for (Item item : items)
                titles.add(item.getTitle());
            ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, titles);

            listView.setAdapter(adapter);
            ListItemHandler lih = new ListItemHandler();
            listView.setOnItemClickListener(lih);
        }
        else
            Toast.makeText(this, "Sorry - No data found",
                    Toast.LENGTH_LONG).show();
    }

    private class ListItemHandler implements AdapterView.OnItemClickListener
    {
        public void onItemClick(AdapterView<?> parent, View view,
                                int position, long id)
        {
            Item selectedItem = listItems.get(position);
            Uri uri = Uri.parse(selectedItem.getLink());
            Intent browserIntent = new Intent(Intent.ACTION_VIEW, uri);
            startActivity(browserIntent);
        }
    }
}
