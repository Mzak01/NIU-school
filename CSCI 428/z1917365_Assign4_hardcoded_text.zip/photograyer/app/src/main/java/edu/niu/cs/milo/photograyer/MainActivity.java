package edu.niu.cs.milo.photograyer;

        import android.content.Intent;
        import android.content.pm.PackageManager;
        import android.graphics.Bitmap;
        import android.graphics.Canvas;
        import android.graphics.Color;
        import android.graphics.Paint;
        import android.graphics.RectF;
        import android.os.Bundle;
        import android.provider.MediaStore;
        import androidx.appcompat.app.AppCompatActivity;
        import android.widget.ImageView;
        import android.widget.Toast;

public class MainActivity extends AppCompatActivity
{
    private static final int PHOTO_REQUEST = 1;
    private Bitmap bitmap;
    private ImageView imageView;

    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        imageView = (ImageView) findViewById(R.id.picture);

        PackageManager manager = this.getPackageManager();
        if (manager.hasSystemFeature(PackageManager.FEATURE_CAMERA))
        {
            Intent takePictureIntent
                    = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            startActivityForResult(takePictureIntent, PHOTO_REQUEST);
        }
        else
        {
            Toast.makeText(this,
                    "Sorry - Your device does not have a camera",
                    Toast.LENGTH_LONG).show();
        }
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PHOTO_REQUEST && resultCode == RESULT_OK)
        {
            Bundle extras = data.getExtras();
            bitmap = (Bitmap) extras.get("data");
            bitmap = setTextBubble(bitmap, "Fine Shyt");
            imageView.setImageBitmap(bitmap);
        }
    }

    private Bitmap setTextBubble(Bitmap image, String getText) {
        //make the image editable
        Bitmap imageCopy = image.copy(Bitmap.Config.ARGB_8888, true);
        Canvas drawOnImage = new Canvas(imageCopy);

        // Get all the colors
        Paint bubbleBackground = new Paint();
        Paint setTextColor = new Paint();

        bubbleBackground.setColor(Color.parseColor("#867ED3"));
        bubbleBackground.setStyle(Paint.Style.FILL);
        bubbleBackground.setAntiAlias(true); // Pretty and smooth edges

        setTextColor.setColor(Color.BLACK);
        setTextColor.setTextSize(24);
        setTextColor.setAntiAlias(true); //Quality improvement
        setTextColor.setTextAlign(Paint.Align.CENTER);

        //Coordinates
        int edgePadding = 10;
        RectF buildBubble = new RectF(edgePadding, edgePadding,
                image.getWidth() - edgePadding, image.getHeight() / 4);

        // Draw everything
        drawOnImage.drawRoundRect(buildBubble, 20, 20, bubbleBackground);
        drawOnImage.drawText(getText, buildBubble.centerX(), buildBubble.centerY(), setTextColor);

        return imageCopy;
    }
}