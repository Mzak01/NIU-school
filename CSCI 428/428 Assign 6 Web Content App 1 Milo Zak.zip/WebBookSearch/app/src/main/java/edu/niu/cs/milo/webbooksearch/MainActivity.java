//********************************************************
// CSCI428-1              Assign6                SPRING 25
//
// NAME: Milo Zak
//       Z-ID: Z1917365
//
// Write an app similar to the Web Content App we built in Chapter 6: XML and Content Apps.
// Default to as many titles as have been published but add a text field to let users specifiy
//how recent they want the data to be.
//********************************************************
package edu.niu.cs.milo.webbooksearch;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import java.util.ArrayList;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

/* If you find the selecting of one of the items displayed in the ListView
   does not display, set up an AVD of the Pixel 2 API 30. */

public class MainActivity extends AppCompatActivity {
    private final String URL =
            "https://www.nintendoworldreport.com/rss";
    private ListView listView;
    private EditText maxDaysText;
    private Button loadButton;
    private ArrayList<Item> listItems;

    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = (ListView) findViewById(R.id.list_view);

        findViewById(R.id.load_articles_bttn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText daysInput = findViewById(R.id.max_days_text);
                int days = 0;

                try {
                    String input = daysInput.getText().toString();
                    if (!input.isEmpty())
                        days = Integer.parseInt(input);
                } catch (NumberFormatException e) {
                    Toast.makeText(MainActivity.this, "Invalid number of days", Toast.LENGTH_SHORT).show();
                    return;
                }

                ParseTask task = new ParseTask(MainActivity.this, days);
                task.execute(URL);
            }
        });

        // Load all items by default
        ParseTask task = new ParseTask(this, 0);
        task.execute(URL);
    }

    public void displayList(ArrayList<Item> items) {
        listItems = items;
        if (items != null && !items.isEmpty())
        {
            // Build ArrayList of titles to display
            ArrayList<String> titles = new ArrayList<String>();
            for (Item item : items)
                titles.add(item.getTitle());

            ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                    android.R.layout.simple_list_item_1, titles);
            listView.setAdapter(adapter);
            listView.setOnItemClickListener(new ListItemHandler());
        }
        else
            Toast.makeText(this, "Sorry - No data found",
                    Toast.LENGTH_LONG).show();

    }

    private class ListItemHandler implements AdapterView.OnItemClickListener
    {
        public void onItemClick(AdapterView<?> parent, View view,
                                int position, long id)
        {
            Item selectedItem = listItems.get(position);
            Uri uri = Uri.parse(selectedItem.getLink());
            Intent browserIntent = new Intent(Intent.ACTION_VIEW, uri);
            startActivity(browserIntent);
        }
    }
}
