package edu.niu.cs.milo.webbooksearch;

import android.os.AsyncTask;
import android.util.Log;
import java.util.ArrayList;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.Locale;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

public class ParseTask extends AsyncTask<String, Void, ArrayList<Item>>
{
    private MainActivity activity;
    private int searchMaxDays;

    public ParseTask(MainActivity fromActivity, int days)
    {
        activity = fromActivity;
        searchMaxDays = days; // Added to search by days inputed
    }

    protected ArrayList<Item> doInBackground(String... urls)
    {
        try
        {
            SAXParserFactory factory = SAXParserFactory.newInstance();
            SAXParser saxParser = factory.newSAXParser();
            SAXHandler handler = new SAXHandler();
            saxParser.parse(urls[0], handler);

            //set up a handler to get items
            ArrayList<Item> allItems = handler.getItems();

            if (searchMaxDays <= 0) {
                return allItems; // no filtering
            }

            // Getting the filter and doing the math to know the date
            ArrayList<Item> filtered = new ArrayList<>();
            long now = System.currentTimeMillis();
            long cutoff = now - (long) searchMaxDays * 24 * 60 * 60 * 1000;

            SimpleDateFormat formatter = new SimpleDateFormat("E, dd MMM yyyy HH:mm:ss Z", Locale.ENGLISH);

            for (Item item : allItems) {
                try {
                    Date pubDate = formatter.parse(item.getPublishDate());
                    if (pubDate != null && pubDate.getTime() >= cutoff) {
                        filtered.add(item);
                    }
                } catch (Exception ignored) {
                    // Ignore dbad dates
                }
            }

            return filtered;
        }
        catch (Exception e)
        {
            Log.w("MainActivity", e.toString());
            return null;
        }
    }

    protected void onPostExecute (ArrayList<Item> returnedItems)
    {
        activity.displayList(returnedItems);
    }
}
