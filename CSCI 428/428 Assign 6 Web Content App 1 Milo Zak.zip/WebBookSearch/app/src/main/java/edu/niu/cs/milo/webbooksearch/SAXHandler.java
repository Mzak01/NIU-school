package edu.niu.cs.milo.webbooksearch;

import java.util.ArrayList;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class SAXHandler extends DefaultHandler {
    private boolean validText;
    private String element = "";
    private Item currentItem;
    private ArrayList<Item> items;

    public SAXHandler()
    {
        validText = false;
        items = new ArrayList<>();
    }

    public ArrayList<Item> getItems()
    {
        return items;
    }

    public void startElement(String uri, String localName,
                             String startElement, Attributes attributes)
                             throws SAXException
    {
        validText = true;
        element = startElement;
        if (startElement.equals("item")) // start current item
            currentItem = new Item("", "", ""); // Added one for publish date
    }

    public void endElement(String uri, String localName,
                           String endElement) throws SAXException
    {
        validText = false;
        if (endElement.equals("item")) // add current item to items
            items.add(currentItem);
    }

    public void characters(char[] ch, int start,
                           int length) throws SAXException
    {
        if (currentItem != null && element.equals("title") && validText)
            currentItem.setTitle(new String(ch, start, length));
        else if (currentItem != null && element.equals("link") && validText)
            currentItem.setLink(new String(ch, start, length));
        else if (currentItem != null && element.equals("pubDate") && validText)
            currentItem.setPublishDate(new String(ch, start, length));

    }
}
