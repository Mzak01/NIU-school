package edu.niu.cs.milo.webbooksearch;

public class Item {
    private String title;
    private String link;
    private String publishDate;

    public Item(String newTitle, String newLink, String newPubDate)
    {
        setTitle(newTitle);
        setLink(newLink);
        setPublishDate(newPubDate); // New to handle pub date
    }

    public void setTitle(String newTitle)
    {
        title = newTitle;
    }

    public void setLink(String newLink)
    {
        link = newLink;
    }

    //Get publisher date
    public void setPublishDate(String newPublishDate) {
        publishDate = newPublishDate;
    }

    public String getTitle()
    {
        return title;
    }

    public String getLink()
    {
        return link;
    }

    //return publisher date
    public String getPublishDate() {
        return publishDate;
    }

    //added published date to the string to search what inputed
    public String toString() {
        return title + "; " + link + "; " + publishDate;
    }
}
