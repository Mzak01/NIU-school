//********************************************************
// CSCI428-1              Assign2                SPRING 25
//
// NAME: Milo Zak
//       Z-ID: Z1917365
//
// write an Android application that
// will be a traffic light app using fragments
//
//********************************************************
package edu.niu.cs.milo.z1917365_project2;

public class LightsModel {
    private int currentLight = 0;   //0-red
                                    //1-yellow
                                    //2-green
    // Returns the current light on
    public int getCurrentLight() {
        return currentLight;
    }

    //cycles through each light state
    public void getNextLight() {
        currentLight = (currentLight + 1 ) % 3;
    }

} //end LightsModel
