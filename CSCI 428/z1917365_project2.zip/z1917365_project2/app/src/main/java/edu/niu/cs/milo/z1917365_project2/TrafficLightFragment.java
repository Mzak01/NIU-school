//********************************************************
// CSCI428-1              Assign2                SPRING 25
//
// NAME: Milo Zak
//       Z-ID: Z1917365
//
// write an Android application that
// will be a traffic light app using fragments
//
//********************************************************
package edu.niu.cs.milo.z1917365_project2;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class TrafficLightFragment extends Fragment {

    // ImageView for the buttons
    private ImageView redLight;
    private ImageView yellowLight;
    private ImageView greenLight;
    private LightsModel lightsModel;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.traffic_light_fragment, container, false);

        // Initialize the ImageViews
        redLight = view.findViewById(R.id.redLight);
        yellowLight = view.findViewById(R.id.yellowLight);
        greenLight = view.findViewById(R.id.greenLight);

        // Initialize LightsModel to track lights
        lightsModel = new LightsModel();

        //Show the red light first
        updateLightVisibility();
        return view;
    } //end onCreateView


    // Update visibility
    public void updateLightVisibility() {
        int currentLight = lightsModel.getCurrentLight();

        // Set the visibility
        redLight.setVisibility(currentLight == 0 ? View.VISIBLE : View.INVISIBLE);
        yellowLight.setVisibility(currentLight == 1 ? View.VISIBLE : View.INVISIBLE);
        greenLight.setVisibility(currentLight == 2 ? View.VISIBLE : View.INVISIBLE);
    }//end updateLightVisibility

    //Change light state
    public void switchLight() {
        lightsModel.getNextLight();
        updateLightVisibility();
    }// End SwitchLight
}//end TrafficLightFragment
