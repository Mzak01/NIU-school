//********************************************************
// CSCI428-1              Assign2                SPRING 25
//
// NAME: Milo Zak
//       Z-ID: Z1917365
//
// write an Android application that
// will be a traffic light app using fragments
//
//********************************************************
package edu.niu.cs.milo.z1917365_project2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    private LightsModel lightsModel;

    // OnCreate method to make the view
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //set up model
        if (savedInstanceState == null) {
            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
            transaction.replace(R.id.fragmentContainer, new TrafficLightFragment());    //pull fragments
            transaction.replace(R.id.fragmentButtonContainer, new ButtonFragment());
            transaction.commit();
        }
    }//end OnCreate
}//end MainActivity